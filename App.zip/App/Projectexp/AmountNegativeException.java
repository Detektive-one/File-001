package Projectexp;
public class AmountNegativeException extends Exception{
	public AmountNegativeException(String sn){
		super(sn);
	}
	
}