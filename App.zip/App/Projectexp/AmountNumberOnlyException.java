package Projectexp;
public class AmountNumberOnlyException extends Exception{
	public AmountNumberOnlyException(String sn){
		super(sn);
	}
	
}